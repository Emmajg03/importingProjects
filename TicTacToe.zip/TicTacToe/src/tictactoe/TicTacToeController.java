package tictactoe;

/*TicTacToe in JavaFX
//Can play TicTacToe with two player, or against computer (easy or hard)
//Author: Emma Glass
//Date: Oct 19th, 2020
//Learning how to use JavaFX
*/

import java.util.Hashtable;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class TicTacToeController {
	
	//declaring variables and arrays
	private boolean isFirstPlayer = true;
	
	String buttons[][] = {{"b1", "b4", "b7"}, {"b2", "b5", "b8"}, {"b3", "b6", "b9"}, {"b1", "b2", "b3"}, 
						{"b4", "b5", "b6"}, {"b7", "b8", "b9"}, {"b1", "b5", "b9"}, {"b3", "b5", "b7"}};
	
	@FXML Button b1;
	@FXML Button b2;
	@FXML Button b3;
	@FXML Button b4;
	@FXML Button b5;
	@FXML Button b6;
	@FXML Button b7;
	@FXML Button b8;
	@FXML Button b9;
	@FXML GridPane gameBoard;
	@FXML MenuItem clickedMenu;
	
	Stage primaryStage;
	Stage secondaryStage;
	Stage tertiaryStage;
	Stage winStage;
	Stage loseStage;
	int count = 0;
	int count2 = 0;
	int placed = 0;
	String pick;
	boolean easy = false;
	boolean hard = false;
	boolean win = false;
	boolean twoPlayer = true;
	boolean turn = true;
	
	public void startButton (ActionEvent evt) {
		
		closeCurrentWindow(evt);
		
		try {
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("tictactoe.fxml"));
			Scene scene = new Scene(root,300,320);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage = new Stage();
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.showAndWait();
		} catch(Exception e) {
			e.printStackTrace();
		}
	
	}
	
	//if one of the 9 squares in pressed
	public void buttonClickHandler (ActionEvent evt) {
		
		//declaring variables
		Button clickedButton = (Button) evt.getTarget();
		String buttonLabel = clickedButton.getText();
		
		//easy mode
		if (win == false && easy == true) {
			
			if ("".equals(buttonLabel) && turn == true) {
				
				clickedButton.setText("X");
				turn = false;
				placed++;
				
			}
			
			find3InARow(evt);
			
			if (turn == false) {
				
				easyMode(evt);
			
			}
			
		}
		
		//hard mode
		if (win == false && hard == true) {
			
			if ("".equals(buttonLabel) && turn == true) {
				
				clickedButton.setText("X");
				turn = false;
				placed++;
				
			}
			
			find3InARow(evt);
			
			if (turn == false) {
				
				hardMode(evt);
			
			}
			
		}
		
		//two player
		if (win == false && twoPlayer == true) {
			
			//X's turn
			if ("".equals(buttonLabel) && isFirstPlayer == true) {
			
				clickedButton.setText("X");
				isFirstPlayer = false;
				placed++;
			
			// O's turn
			}else if ("".equals(buttonLabel) && isFirstPlayer == false) {
			
				clickedButton.setText("O");
				isFirstPlayer = true;
				placed++;
			
			}
			
			//check for win
			find3InARow(evt);
		
		}
		
	}
	
	//if a menu button is clicked
	public void menuClickHandler (ActionEvent evt) {
		
		//declaring variables
		MenuItem clickedMenu = (MenuItem) evt.getTarget();
		String menuLabel = clickedMenu.getText();
		
		//two player button
		if ("Two Player".equals(menuLabel)) {
			
			//declaring variables
			easy = false;
			hard = false;
			twoPlayer = true;
			win = false;
			placed = 0;
			
			ObservableList<Node> buttons = gameBoard.getChildren();
			
			//resets board
			buttons.forEach(btn -> {
				
				((Button) btn).setText("");
				
				btn.getStyleClass().remove("winning-button");
				
			});
			
			//X goes first
			isFirstPlayer = true;
			
		}
		
		//easy mode button
		if ("Computer (Easy)".equals(menuLabel)) {
			
			//declaring variables
			easy = true;
			hard = false;
			twoPlayer = false;
			win = false;
			placed = 0;
			
			ObservableList<Node> buttons = gameBoard.getChildren();
			
			//resets board
			buttons.forEach(btn -> {
				
				((Button) btn).setText("");
				
				btn.getStyleClass().remove("winning-button");
				
			});
			
		}
		
		//hard mode button
		if ("Computer (Hard)".equals(menuLabel)) {
			
			//declaring variables
			easy = false;
			hard = true;
			twoPlayer = false;
			win = false;
			placed = 0;
			
			ObservableList<Node> buttons = gameBoard.getChildren();
			
			//resets board
			buttons.forEach(btn -> {
				
				((Button) btn).setText("");
				
				btn.getStyleClass().remove("winning-button");
				
			});
			
		}
		
		//'About' menu button
		if ("About".equals(menuLabel)) {
			
			//opens new window
			openAboutWindow();
			
		}
		
		//'How To Play' menu button
		if ("How To Play".equals(menuLabel)) {
			
			//opens new window
			openHowToWindow();
			
		}
		
		//quit button
		if ("Quit".equals(menuLabel)) {
			
			//closes window
			Platform.exit();
			
		}
		
	}
	
	//checks for win
	private void find3InARow(ActionEvent evt) {
		
		//button id hashtable
		Hashtable<String, Button> buttonIds = new Hashtable<String, Button>();
		buttonIds.put("b1", b1);
		buttonIds.put("b2", b2);
		buttonIds.put("b3", b3);
		buttonIds.put("b4", b4);
		buttonIds.put("b5", b5);
		buttonIds.put("b6", b6);
		buttonIds.put("b7", b7);
		buttonIds.put("b8", b8);
		buttonIds.put("b9", b9);
		
		//loops through buttons array
		for (int i = 0; i < 8; i++) {
			
			for (int j = 0; j < 3; j ++) {
				
				//checks for match
				if ((((Button)evt.getSource()).getId()).equals(buttons[i][j])) {
					
					//loops through part that matched
					for (int k = 0; k < 3; k++) {
						
						//equals X?
						if (buttonIds.get(buttons[i][k]).getText().equals("X")) {
							
							count++;
							
						}
						
						//equals O?
						if (buttonIds.get(buttons[i][k]).getText().equals("O")) {
							
							count--;
							
						}
						
						//do all three match?
						if (Math.abs(count) == 3) {
							
							//highlight win
							highlightWinningCombo (buttonIds.get(buttons[i][0]), buttonIds.get(buttons[i][1]), buttonIds.get(buttons[i][2]), evt);
							
						}
						
					}
					
					count = 0;
					
				}
				
			}
			
		}
		
		/*----------basic win check
		//Row 1
		if ("" != b1.getText() && b1.getText() == b2.getText() && b2.getText() == b3.getText()) {
			
			highlightWinningCombo (b1, b2, b3);
			
		}
		
		//Row 2
		if ("" != b4.getText() && b4.getText() == b5.getText() && b5.getText() == b6.getText()) {
			
			highlightWinningCombo (b4, b5, b6);
			
		}
		
		//Row 3
		if ("" != b7.getText() && b7.getText() == b8.getText() && b8.getText() == b9.getText()) {
			
			highlightWinningCombo (b7, b8, b9);
			
		}
		
		//Column 1
		if ("" != b1.getText() && b1.getText() == b4.getText() && b4.getText() == b7.getText()) {
			
			highlightWinningCombo (b1, b4, b7);
			
		}
		
		//Column 2
		if ("" != b2.getText() && b2.getText() == b5.getText() && b5.getText() == b8.getText()) {
			
			highlightWinningCombo (b2, b5, b8);
			
		}
		
		//Column 3		
		if ("" != b3.getText() && b3.getText() == b6.getText() && b6.getText() == b9.getText()) {
			
			highlightWinningCombo (b3, b6, b9);
			
		}
		
		//Diagonal 1
		if ("" != b1.getText() && b1.getText() == b5.getText() && b5.getText() == b9.getText()) {
			
			highlightWinningCombo (b1, b5, b9);
			
		}
		
		//Diagonal 2
		if ("" != b3.getText() && b3.getText() == b5.getText() && b5.getText() == b7.getText()) {
			
			highlightWinningCombo (b3, b5, b7);
			
		}
		*/
	}
	
	//checks for computer win on easy and hard mode
	private void find3InARowO(ActionEvent evt) {
		
		//button id hashtable
		Hashtable<String, Button> buttonIds = new Hashtable<String, Button>();
		buttonIds.put("b1", b1);
		buttonIds.put("b2", b2);
		buttonIds.put("b3", b3);
		buttonIds.put("b4", b4);
		buttonIds.put("b5", b5);
		buttonIds.put("b6", b6);
		buttonIds.put("b7", b7);
		buttonIds.put("b8", b8);
		buttonIds.put("b9", b9);
		
		//loops through buttons array
		for (int i = 0; i < 8; i++) {
			
			for (int j = 0; j < 3; j ++) {
				
				//checks for match
				if (pick.equals(buttons[i][j])) {
					
					//loops through part that matched
					for (int k = 0; k < 3; k++) {
						
						//equals X?
						if (buttonIds.get(buttons[i][k]).getText().equals("X")) {
							
							count++;
							
						}
						
						//equals O?
						if (buttonIds.get(buttons[i][k]).getText().equals("O")) {
							
							count--;
							
						}
						
						//do all three match?
						if (Math.abs(count) == 3) {
							
							//highlight win
							highlightWinningCombo (buttonIds.get(buttons[i][0]), buttonIds.get(buttons[i][1]), buttonIds.get(buttons[i][2]), evt);
							
						}
						
					}
					
					count = 0;
					
				}
				
			}
			
		}
		
	}
	
	//highlights the winning combination
	private void highlightWinningCombo (Button first, Button second, Button third, ActionEvent evt) {
		
		//changes colours
		first.getStyleClass().add("winning-button");
		second.getStyleClass().add("winning-button");
		third.getStyleClass().add("winning-button");
		
		win = true;
		
		if (first.getText().equals("X")) {
			
			try {
				
				Pane root = (Pane)FXMLLoader.load(getClass().getResource("WinningScreen.fxml"));
				Scene scene = new Scene(root,300,300);		
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				winStage = new Stage();
				winStage.setScene(scene);
				winStage.setResizable(false);
				winStage.showAndWait();
				
			} catch(Exception e) {
				
				e.printStackTrace();
				
			}
			
		}
		
		if (first.getText().equals("O")) {
			
			try {
				
				Pane root = (Pane)FXMLLoader.load(getClass().getResource("LosingScreen.fxml"));
				Scene scene = new Scene(root,300,300);		
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				loseStage = new Stage();
				loseStage.setScene(scene);
				loseStage.setResizable(false);
				loseStage.showAndWait();
				
			} catch(Exception e) {
				
				e.printStackTrace();
				
			}
			
		}
		
	}
	
	//new window for how to play button
	private void openHowToWindow() {
		
		try {
			
			// load the pop up you created
			Pane howTo = (Pane)FXMLLoader.load(getClass().getResource("HowToPlay.fxml.fxml"));
				
			// create a new scene
			Scene howToScene = new Scene(howTo,250,250);

			// add css to the new scene		
			howToScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			//create new stage to put scene in
			secondaryStage = new Stage();
			secondaryStage.setScene(howToScene);
			secondaryStage.setResizable(false);
			secondaryStage.showAndWait();
			
		} catch(Exception e) {
			
			e.printStackTrace();
			
		}
	
	}
	
	//new window for about button
	private void openAboutWindow () {

		try {
			
			// load the pop up you created
			Pane root = (Pane)FXMLLoader.load(getClass().getResource("about.fxml"));
				
			// create a new scene
			Scene scene = new Scene(root,250,250);

			// add css to the new scene		
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			//create new stage to put scene in
			tertiaryStage = new Stage();
			tertiaryStage.setScene(scene);
			tertiaryStage.setResizable(false);
			tertiaryStage.showAndWait();
			
		} catch(Exception e) {
			
			e.printStackTrace();
			
		}
	
	}
	
	// close the window that is currently open
	//it figures out where the event came from and closes that stage
	public void closeCurrentWindow (final ActionEvent evt) {
		
	    final Node source = (Node) evt.getSource();
	    final Stage stage = (Stage) source.getScene().getWindow();
	    stage.close();
	    
	}
	
	//computer moves - easy mode
	private void easyMode (ActionEvent evt) {
		
		//declare variables
		boolean check = false;
		
		//button id hashtable
		Hashtable<String, Button> buttonIds = new Hashtable<String, Button>();
		buttonIds.put("b1", b1);
		buttonIds.put("b2", b2);
		buttonIds.put("b3", b3);
		buttonIds.put("b4", b4);
		buttonIds.put("b5", b5);
		buttonIds.put("b6", b6);
		buttonIds.put("b7", b7);
		buttonIds.put("b8", b8);
		buttonIds.put("b9", b9);
		
		//looping until it finds an open spot
		while (check == false && win == false && placed != 9) {
			
			//saves the button id of its choice
			pick = "b" + String.valueOf((int)(Math.random()*9) +1);
			
			//if open spot
			if (buttonIds.get(pick).getText().equals("")) {
				
				buttonIds.get(pick).setText("O");
				check = true;
				turn = true;
				placed++;
				
			}
			
		}
		
		find3InARowO(evt);
		
	}
	
	//computer moves - hard mode
	private void hardMode (ActionEvent evt) {
		
		//declare variables
		boolean check = false;
		boolean flag = true;
		
		//button id hashtable
		Hashtable<String, Button> buttonIds = new Hashtable<String, Button>();
		buttonIds.put("b1", b1);
		buttonIds.put("b2", b2);
		buttonIds.put("b3", b3);
		buttonIds.put("b4", b4);
		buttonIds.put("b5", b5);
		buttonIds.put("b6", b6);
		buttonIds.put("b7", b7);
		buttonIds.put("b8", b8);
		buttonIds.put("b9", b9);
		
		if (flag == true && win == false) {
			
			//loops through buttons array
			for (int i = 0; i < 8; i++) {
				
				for (int j = 0; j < 3; j ++) {
					
					// if the button text equals O
					if (buttonIds.get(buttons[i][j]).getText().equals("O")) {
						
						//loops through that part of the array
						for (int k = 0; k < 3; k++) {
							
							//if button text is O, add one to the counter
							if (buttonIds.get(buttons[i][k]).getText().equals("O")) {
								
								count2++;
								
							}
							
							//if two of then are O's
							if (count2 == 2) {
								
								for (int l = 0; l < 3; l++) {
									
									//put at O in the open spot
									if (buttonIds.get(buttons[i][l]).getText().equals("") && flag == true) {
										
										buttonIds.get(buttons[i][l]).setText("O");
										pick = buttons[i][l];
										flag = false;
										turn = true;
										placed++;
										
									}
										
								}
									
							}
								
						}
							
					}
						
					count2 = 0;
						
				}
					
			}
			
		}
		
		if (flag == true && win == false) {
			
			//loops through buttons array
			for (int i = 0; i < 8; i++) {
			
				for (int j = 0; j < 3; j ++) {
				
					//if there is an X
					if (buttonIds.get(buttons[i][j]).getText().equals("X")) {
						
						//check that line
						for (int k = 0; k < 3; k++) {
						
							//count the X's in that line
							if (buttonIds.get(buttons[i][k]).getText().equals("X")) {
							
								count2++;
							
							}
							
							//if there are 2 X's,
							if (count2 == 2) {
							
								for (int l = 0; l < 3; l++) {
								
									//put an O in the empty space
									if (buttonIds.get(buttons[i][l]).getText().equals("") && flag == true) {
									
										buttonIds.get(buttons[i][l]).setText("O");
										pick = buttons[i][l];
										flag = false;
										turn = true;
										placed++;
										
									}
									
								}
								
							}
							
						}
						
					}
					
					count2 = 0;
					
				}
				
			}
			
		}
		
		if (flag == true && win == false) {
		
			//loops through buttons array
			for (int i = 0; i < 8; i++) {
			
				for (int j = 0; j < 3; j ++) {
				
					//if there's an O,
					if (buttonIds.get(buttons[i][j]).getText().equals("O")) {
						
						for (int k = 0; k < 3; k++) {
						
							//count empty spaces in that line
							if (buttonIds.get(buttons[i][k]).getText().equals("")) {
								
								count2++;
								
							}
							
							//if there's 2 empty spaces,
							if (count2 == 2) {
								
								for (int l = 0; l < 3; l++) {
								
									//put an O in one of them
									if (buttonIds.get(buttons[i][l]).getText().equals("") && flag == true) {
										
										buttonIds.get(buttons[i][l]).setText("O");
										pick = buttons[i][l];
										flag = false;
										turn = true;
										placed++;
										
									}
										
								}
									
							}
								
						}
							
					}
						
					count2 = 0;
						
				}
					
			}
			
		}
		
		if (flag == true && win == false) {
		
			while (check == false && flag == true && placed != 9) {
			
				//pick a random empty spot
				pick = "b" + String.valueOf((int)(Math.random()*9) +1);
		
				//if its empty,
				if ((buttonIds.get(pick)).getText().equals("")) {
			
					buttonIds.get(pick).setText("O");
					check = true;
					flag = false;
					turn = true;
					placed++;
					
				}
				
			}
			
		}
		
		find3InARowO(evt);
		
	}
	
	public void quit () {
		
		Platform.exit();
		
	}

}
