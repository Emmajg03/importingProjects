package tictactoe;
	
/*TicTacToe in JavaFX
//Can play TicTacToe with two player, or against computer (easy or hard)
//Author: Emma Glass
//Date: Oct 19th, 2020
//Learning how to use JavaFX
*/

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.fxml.FXMLLoader;

public class Main extends Application {
	@Override
	public void start(Stage startStage) {
		try {
			Pane howTo = (Pane)FXMLLoader.load(getClass().getResource("StartScreen.fxml"));
			Scene howToScene = new Scene(howTo,400,500);	
			howToScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			startStage = new Stage();
			startStage.setScene(howToScene);
			startStage.setResizable(false);
			startStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
